package ch.noseryoung.uek295yacordiscount;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Uek295yacordiscountApplicationTests {

	@Test
	void contextLoads() {
	}

}
