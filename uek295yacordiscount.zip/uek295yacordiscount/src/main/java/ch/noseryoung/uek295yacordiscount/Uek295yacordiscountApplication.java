package ch.noseryoung.uek295yacordiscount;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Uek295yacordiscountApplication {

	public static void main(String[] args) {
		SpringApplication.run(Uek295yacordiscountApplication.class, args);
	}

}
